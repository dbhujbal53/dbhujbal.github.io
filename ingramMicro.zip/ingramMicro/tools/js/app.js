// MODULE
var ingramMicro=angular.module('ingramMicro',['ui.router']);

// ROUTE
ingramMicro.config(['$stateProvider','$urlRouterProvider',function($stateProvider,$urlRouterProvider){
	
	$stateProvider
	.state('ingramMicro',{
		url:'/ingramMicro',
		templateUrl:'template/header.html',
		abstract:true,
		controller:'MainController'
	})
	.state('ingramMicro.Home',{
		url:'/Home',
		templateUrl:'template/home.html',
		controller:'HomeController'
	})
	.state('ingramMicro.Model',{
		url:'/Model/:brandName/:modelName',
		templateUrl:'template/details.html',
		controller:'ModelController'
	});
	$urlRouterProvider.otherwise('/ingramMicro/Home');
}]);

//Controller
ingramMicro
.controller('MainController',['$scope','$rootScope','$http','$state',function($scope,$rootScope,$http,$state){
	
	
	 $http({method: 'POST', url: 'tools/js/mobiledata.json'}).success(function(data) {
		$rootScope.brandList= data;
	 });

	
}])
.controller('HomeController',['$scope','$rootScope','$state','$stateParams',function($scope,$rootScope,$state,$stateParams){
	
	$scope.brand="Select Brand";
	$scope.model="Select Model";
	
	$scope.disabledModel=true;
	$scope.disabledSearch=true;
	
	
	$scope.changeBrand=function(name){
		$scope.model="Select Model";
		$scope.brand=name;
		$scope.disabledModel=false;
		$scope.disabledSearch=true;
		$scope.modelList=$rootScope.brandList[name];
	}
	
	$scope.changeModel=function(name){
		$scope.model=name;	
		$scope.disabledSearch=false;
	}
	
	$scope.getModelDetails=function(brandName,modelName){
		var params = {"brandName":brandName, "modelName":modelName};
		$state.go('ingramMicro.Model',params);
		
	}
	
	
}])
.controller('ModelController',['$scope','$rootScope','$state','$stateParams',function($scope,$rootScope,$state,$stateParams){

	var brndNm=$stateParams.brandName;
	var mdlNm=$stateParams.modelName
	console.log($stateParams);
	$rootScope.modelDetails = $rootScope.brandList[brndNm][mdlNm];
	
}]);